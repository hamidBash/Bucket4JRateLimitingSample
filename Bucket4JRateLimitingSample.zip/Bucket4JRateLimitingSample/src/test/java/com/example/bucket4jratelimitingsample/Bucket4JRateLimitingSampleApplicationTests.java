package com.example.bucket4jratelimitingsample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bucket4JRateLimitingSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
