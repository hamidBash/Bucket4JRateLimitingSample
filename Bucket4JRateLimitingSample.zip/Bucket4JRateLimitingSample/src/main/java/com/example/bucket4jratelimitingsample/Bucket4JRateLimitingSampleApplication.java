package com.example.bucket4jratelimitingsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bucket4JRateLimitingSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bucket4JRateLimitingSampleApplication.class, args);
	}

}
